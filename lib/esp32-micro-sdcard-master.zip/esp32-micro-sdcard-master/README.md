visit IOTSHARING.COM for more
# esp32_nanosdcard
this library is for Arduino, I modified it to adapt with ESP32
